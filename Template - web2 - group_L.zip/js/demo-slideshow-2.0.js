$(document).ready(function(){
    $('.owl-carousel').owlCarousel({
        loop:true,
        nav:true,
        autoplay:true,
        autoplayTimeout:2000,
        autoplayHoverPause:false,
        animateOut: 'fadeOut',
        animateIn: 'fadeIn',
        items:1
    })
});