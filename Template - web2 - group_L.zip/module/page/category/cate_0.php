<div class="type_16_cate_0">
	<div style="" class="vc_row wpb_row vc_row-fluid">
		<div class="wpb_column vc_column_container vc_col-sm-6">
			<div class="vc_column-inner ">
				<div class="wpb_wrapper">
					<div class="wpb_text_column wpb_content_element ">
						<div class="wpb_wrapper">
							<h2 id="view" class="text-uppercase text-center" style="text-align: center;">
								<small>STARTING AT $120 / NIGHT</small>SIGNATURE WATER VIEW
							</h2>
							<p style="text-align: center;">
								<img class="aligncenter wp-image-698 size-full" src="../../images/category/content-rooms-1.jpg" alt="content-rooms-1">
							</p>
							<p style="text-align: center;">
								Phasellus laoreet lorem vel dolor tempus vehicula. Integer legentibus erat a ante historiarum dapibus. Plura mihi bona sunt, inclinet, amari petere vellent. Quae vero auctorem tractata ab fiducia dicuntur.
							</p>
							<p style="text-align: center;">
								<a class="btn btn-inline" href="#">Book the Signature Water View Now</a>
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="wpb_column vc_column_container vc_col-sm-6">
			<div class="vc_column-inner ">
				<div class="wpb_wrapper">
					<div class="wpb_text_column wpb_content_element ">
						<div class="wpb_wrapper">
							<h2 id="sideview" class="text-uppercase text-center" style="text-align: center;">
								<small>STARTING AT $120 / NIGHT</small>SIGNATURE WATER SIDE
							</h2>
							<p style="text-align: center;">
								<img class="aligncenter wp-image-695 size-full" src="../../images/category/content-rooms.jpg" alt="content-rooms">
							</p>
							<p style="text-align: center;">
								Phasellus laoreet lorem vel dolor tempus vehicula. Integer legentibus erat a ante historiarum dapibus. Plura mihi bona sunt, inclinet, amari petere vellent. Quae vero auctorem tractata ab fiducia dicuntur.
							</p>
							<p style="text-align: center;">
								<a class="btn btn-inline" href="#">Book the Signature Water Side Now</a>
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>