<div class="type_45">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="word3">
                    <p style="margin-top:30px;">Unam incolunt Belgae, aliam Aquitani, tertiam. Idque Caesaris facere 
                        <br>voluntate liceret: sese habere. Quis aute iure reprehenderit in voluptate 
                        <br>velit esse. Ab illo tempore, ab est sed immemorabili. Quam temere in 
                        <br>vitiis legem.</p>
                    <h3>Curabitur blandit tempus ardua</h3>
                    <p>Salutantibus vitae elit libero, a pharetra augue. At nos hinc posthac, sitientis piros Afros. Quisque ut dolor gravida, placerat libero vel, euismod. Ut enim ad minim veniam, quis nostrud exercitation. Unam incolunt Belgae, aliam Aquitani, tertiam. Unam incolunt Belgae, aliam Aquitani, tertiam. Tityre, tu patulae recubans sub tegmine fagi dolor. Curabitur est gravida.</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="container">
                    <div class="images">
                        <img src="../../images/category/content-rooms-4.jpg" style="width: 50%;" >
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>