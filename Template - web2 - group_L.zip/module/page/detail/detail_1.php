<div class="detail-1 container">
    <div class="row">
        <div class="col-sm-6">
            <img src="../../images/detail/content-room.jpg" alt="content-room">
        </div>
        <div class="col-sm-6">
            <div class="paragraph">
                <p class="lead">Quisque ut dolor gravida, placerat libero vel, euismod. Salutantibus vitae elit libero,
                    a pharetra augue. Paullum deliquit, ponderibus modulisque suis ratio utitur.</p>
                <p>Prima luce, cum quibus mons aliud consensu ab eo. Praeterea iter est quasdam res quas ex communi.
                    Etiam habebis sem dicantur magna mollis euismod. Ut enim ad minim veniam, quis nostrud exercitation.
                    Vivamus sagittis lacus vel augue laoreet rutrum faucibus. Contra legem facit qui id facit. Cum
                    ceteris in veneratione tui montes, nascetur mus. Non equidem invideo, miror magis posuere velit
                    aliquet.</p>
                <h3>Quae vero auctorem tractata ab fiducia dicuntur. Quisque placerat facilisis egestas.</h3>
                <p>Idque Caesaris facere voluntate liceret: sese habere. Etiam habebis sem dicantur magna mollis
                    euismod. Quo usque tandem abutere, Catilina, patientia nostra? Hi omnes lingua, institutis, legibus
                    inter se differunt. Contra legem facit qui id facit quod lex prohibet. Quisque placerat facilisis
                    egestas cillum dolore.</p>
            </div>
        </div>
    </div>
</div>