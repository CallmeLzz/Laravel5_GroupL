<div class="type-34">
    <div class="banner owl-carousel owl-theme">
        <div class="item">
            <img src="../../images/home/photodune-1256180-luxury-hotel-resort-at-twilight-m.jpg">
        </div>
        <div class="item">
            <img src="../../images/home/iStock_000010325467_Full1.jpg">
        </div>
        <div class="item">
            <img src="../../images/home/splash.jpg">
        </div>
    </div>
    <div style="clear: both;"></div>
</div>