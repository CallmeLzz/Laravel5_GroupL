<div class="type_16_content_0">
	<div class="vc_row wpb_row vc_row-fluid">
		<div class="wpb_column vc_column_container vc_col-sm-8 vc_col-sm-offset-2">
			<div class="vc_column-inner ">
				<div class="wpb_wrapper">
					<div class="wpb_text_column wpb_content_element ">
						<div class="wpb_wrapper">
							<h1 style="text-align: center;"><small>What can you do with the Leisure Template?</small>AWARD WINNING RESORT</h1>
							<p class="lead" style="text-align: center;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam non ornare eros. Ut pharetra ornare lorem, sit amet bibendum quam imperdiet ut.</p>
							<p style="text-align: center;">Duis diam eros, dignissim sed condimentum ac, vehicula nec nisl. Suspendisse condimentum libero tempus, accumsan augue et, varius dui. Morbi justo tortor, tincidunt ornare magna ut, molestie mattis enim. Cras ac justo et augue suscipit euismod vel eget lectus. Proin vehicula nunc arcu, pulvinar accumsan.</p>
							<p style="text-align: center;"><a class="btn-inline btn" href="#">What is happening at the Leisure Center?</a></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>