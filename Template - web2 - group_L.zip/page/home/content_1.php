<div class="type_16_content">
	<div class="vc_row wpb_row vc_row-fluid content-padding-xxl vc_custom_1456180226251 vc_row-has-fill vc_general vc_parallax vc_parallax-content-moving parallax-container">
		<div class="wpb_column vc_column_container vc_col-sm-6 vc_col-sm-offset-6">
			<div class="vc_column-inner ">
				<div class="wpb_wrapper">
					<div class="wpb_text_column wpb_content_element ">
						<div class="wpb_wrapper">
							<h2><small>Discover Nature at it’s Finest</small>PLAY GOLF LIKE A PRO</h2>
							<p>Duis diam eros, dignissim sed condimentum ac, vehicula nec nisl. Suspendissecondimentum libero tempus, accumsan augue et, varius dui. Morbi justo tortor, tincidunt ornare magna ut, molestie mattis enim.</p>
							<p>Cras ac justo et augue suscipit euismod vel eget lectus. Proin vehicula nunc arcu, pulvinar accumsan nulla porta vel. Vivamus malesuada vitae sem ac pellentesque.</p>
							<p><a class="btn btn-inline" href="#">Explore Our Deluxe Golf Course</a></p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<img src="images/home/photo3.jpg" alt="" class="hidden-xs parallax-image pt3">
		<img src="images/home/photo2.jpg" alt="" class="hidden-xs parallax-image pt2">
		<img src="images/home/photo1.jpg" alt="" class="hidden-xs parallax-image pt1">
		<div class="vc_parallax-inner skrollable skrollable-between" data-bottom-top="top: -50%;" data-top-bottom="top: 0%;" style="height: 150%; top: -37.9325%;"></div>
	</div>
</div>